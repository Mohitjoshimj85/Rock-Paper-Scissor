// Selecting DOM elements
const userStep = document.querySelector("#user_step"); // Element to display user's choice
const compStep = document.querySelector("#comp_step"); // Element to display computer's choice
const choices = document.querySelectorAll(".choice"); // List of user's choices
const msg = document.querySelector("#msg"); // Element to display game result

// Function to generate computer's choice
const computer_choice = () => {
    const options = ["rock", "paper", "scissor"]; // Available choices
    const idx = Math.floor(Math.random() * 3); // Generate random index
    return options[idx]; // Return random choice
}

// Function to display game result
const show_result = (result, comp) => {
    if (result === true) { // If user wins
        msg.innerText = "You Win"; // Display win message
        msg.style.backgroundColor = "green"; // Set background color to green
    } else { // If user loses
        msg.innerText = "You Lose"; // Display lose message
        msg.style.backgroundColor = "red"; // Set background color to red
    }
}

// Function to play the game
const playGame = (user) => {
    const comp = computer_choice(); // Generate computer's choice
    console.log("User's choice:", user); // Log user's choice
    console.log("Computer's choice:", comp); // Log computer's choice
    userStep.innerText = user; // Display user's choice
    compStep.innerText = comp; // Display computer's choice
    if (user === comp) { // If it's a draw
        msg.innerText = "Draw"; // Display draw message
        msg.style.backgroundColor = "white"; // Set background color to white
    } else { // If there's a winner
        result = true; // Initialize result as true
        if (user === "rock") { // Check user's choice
            result = comp === "paper" ? false : true; // Determine result
        } else if (user === "paper") { // Check user's choice
            result = comp === "scissor" ? false : true; // Determine result
        } else if (user === "scissor") { // Check user's choice
            result = comp === "rock" ? false : true; // Determine result
        }
        show_result(result, comp); // Display result
    }
}

// Add event listener to each choice
choices.forEach((choice) => {
    choice.addEventListener("click", () => {
        const user_choice = choice.getAttribute("id"); // Get user's choice
        playGame(user_choice); // Play the game
    });
});
